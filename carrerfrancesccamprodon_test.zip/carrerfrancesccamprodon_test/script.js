document.getElementById('testButton').addEventListener('click', function () {
  document.getElementById('result').textContent = 'JavaScript funciona correctament.';
});
